Basic WASD movement

---New
Contact with enemy lowers health
Mini Bosses protect rooms with key
Need Key to confront final Boss
Boss have destuctable limbs
Rooms lock player if there are enemies in room
Press R to reload weapon

---Bugs
Boss placeholder does nothing for now


---Not implemented
Better Asset
No Gui
No GameOver
No Win

